package com.example.android.myperfumeshop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WorkHourae extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_hourae);
    }
}