package com.example.android.myperfumeshop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class two extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
}